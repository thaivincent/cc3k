module item;
import info;

Item::Item(int x, int y): x{x}, y{y} {}

