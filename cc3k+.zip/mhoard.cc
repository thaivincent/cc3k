export module mhoard;

import gold;
using namespace std;

export class MHoard: public Gold {
    
};

