module statuseffect;

StatusEffect::~StatusEffect() {}
