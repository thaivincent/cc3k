module gold;

int Gold::getValue() {
    return value;
}

