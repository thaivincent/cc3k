export module compass;

import item;
using namespace std;

export class Compass: public Item {
    
};
