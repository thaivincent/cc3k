export module item;

using namespace std;

export class Item {
    int x;
    int y;

    public:
        Item(int x, int y);

};

