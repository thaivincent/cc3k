export module dhoard;

import gold;
using namespace std;

export class DHoard: public Gold {
    public:
        bool isDead;
};
