export module barriersuit;

import item;
using namespace std;

export class BarrierSuit: public Item {
    
};
