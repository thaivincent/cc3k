export module pile;

import gold;
using namespace std;

export class Pile: public Gold {
    
};
